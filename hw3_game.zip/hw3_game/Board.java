package hw3_game;

public class Board {

	public static void main (String[] args)
	{
		Player player = new Player();
		
		player.attack();
		player.upgradeLevel();
		
		player.attack();
		player.upgradeLevel();
		
		player.attack();
		player.upgradeLevel();
	}
}
