package strategy;

public interface GradeStrategy {

	public String getGrade(int score);
	
}
