package student;

public class Score {


	String courseName;
	String studentName;
	int score;
	
	public Score(String studentName, String courseName, int score) {
		
		this.studentName = studentName;
		this.courseName = courseName;
		this.score = score;
		
	}
	
	
	
}
